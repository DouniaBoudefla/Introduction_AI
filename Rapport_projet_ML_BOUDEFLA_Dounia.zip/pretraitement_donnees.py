from sklearn.datasets import fetch_california_housing
# Charger le dataset
california = fetch_california_housing()
# Séparer les caractéristiques et la variable cible
X, y = california.data, california.target

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Créer un DataFrame à partir des caractéristiques et de la variable cible
df_california = pd.DataFrame(data=california.data, columns=california.feature_names)
df_california['MedHouseValue'] = california.target

from sklearn.preprocessing import StandardScaler

# Créer un objet StandardScaler
scaler = StandardScaler()

# Ajuster et transformer les données
df_california_scaled = pd.DataFrame(scaler.fit_transform(df_california), columns=df_california.columns)

# Afficher les premières lignes du DataFrame normalisé
print("\nPremières lignes du DataFrame normalisé:\n")
print(df_california_scaled.head())

# Enregistrer le dataframe dans un fichier california_mod.csv
df_california.to_csv('california_mod.csv',sep=";")
print(df_california.info())